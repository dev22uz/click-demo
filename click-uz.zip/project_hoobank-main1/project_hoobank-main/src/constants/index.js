import { people01, people02, people03,  airbnb, binance, coinbase, dropbox,  item2, item,item3,item4, clickcard, blog, blog2, blog3,  } from "../assets";

export const navLinks = [
  {
    id: "premium",
    title: "Click Premium",
  },
  {
    id: "start",
    title: "Click Start",
  },
  {
    id: "click-up",
    title: "Click Up",
  },
  {
    id: "click-hamyon",
    title: "Click hamyon",
  },
  {
    id: "click-card",
    title: "Click Karta",
  },
];

export const features = [
  {
    id: "feature-1",
    icon: item,
    title: "Telefon uchun cashback 5% gacha",
    content:
      "Mobil operatorlarda balans to'ldirishda yanada ko'proq foyda (Beeline, Ucell, Mobiuz, Uzmobile - cashbek 2%, Perfectum - cashbek 5%)",
  },
  {
    id: "feature-3",
    icon: item2,
    title: "To'lovlar uchun ikki baravar Cashback",
    content:
      "Endi kafe, restoran, kommunal xizmatlarga va hokazo to'lovlaringizdan 2 baravar ko'p cashback",
  },
  {
    id: "feature-2",
    icon: item3,
    title: "Bepul o'tkazmalar",
    content:
      "Uzcard/Humo kartalaridan kartalarga oyiga 10 000 000 so'mgacha komissiyasiz o'tkazmalar",
  },
  {
    id: "feature-3",
    icon: item4,
    title: "CLICK BOOM",
    content:
      "Yoningizdagi odamlarga pullarni yanada tezroq va qulayroq o'tkazing",
  },
  
];
export const features2 = [
  {
    id: "feature-1",
    icon: item,
    title: "Pul o'tqazing",
    content:
      "",
  },
  {
    id: "feature-3",
    icon: item2,
    title: "CASHBACK oling",
    content:
      "",
  },
  {
    id: "feature-2",
    icon: item3,
    title: "Bepul o'tkazmalar",
    content:
      "Uzcard/Humo kartalaridan kartalarga oyiga 10 000 000 so'mgacha komissiyasiz o'tkazmalar",
  },
  {
    id: "feature-3",
    icon: item4,
    title: "CLICK BOOM",
    content:
      "Yoningizdagi odamlarga pullarni yanada tezroq va qulayroq o'tkazing",
  },
  
];

export const feedback = [
  {
    id: "feedback-1",
    content:
      "Hamkorimiz Central Park bilan birgalikda biz ajoyib tanlov boshladik!",
    name: "Herman Jensen",
    title: "19.03.2023",
    img: blog,
  },
  {
    id: "feedback-2",
    content:
      "Reels suratga olishni yoqtirasizmi va eng mashhur blogerlar bilan trendlarda bo'lishni xohlaysizmi?",
    name: "Steve Mark",
    title: "18.03.2023",
    img: blog2,
  },
  {
    id: "feedback-3",
    content:
      "Atigi 2 kun qoldi! Premium-statusni chegirma bilan ulashga shoshiling!",
    name: "Kenn Gallagher",
    title: "30.12.2022",
    img: blog3,
  },
];

export const stats = [
  {
    id: "stats-1",
    title: "User Active",
    value: "3800+",
  },
  {
    id: "stats-2",
    title: "Trusted by Company",
    value: "230+",
  },
  {
    id: "stats-3",
    title: "Transaction",
    value: "$230M+",
  },
];

export const footerLinks = [
  {
    title: "Xizmat haqida",
    links: [
      {
        name: "Kompaniya haqida",
        
      },
      {
        name: "Yangiliklar",
        
      },
      {
        name: "Tariflar",
        
      },
      {
        name: "Xavfsizlik",
       
      },
      {
        name: "Bo'sh ish o'rinlari",
        
      },
      {
        name: "Ommaviy oferta",
       
      },
    ],
  },
  
  {
    title: "Yordam",
    links: [
      {
        name: "Tez-tez so'raladigan savollar",
        
      },
      {
        name: "Maxfiylik siyosati",
        
      },
      {
        name: "Hamkorlarga",
        
      },
      {
        name: "Dasturchilar uchun",
       
      },
      {
        name: "Istak va takliflaringiz",
        
      },
    
    ],
  },
  {
    title: "Xizmatlar",
    links: [
      {
        name: "Click hamyon",
        
      },
      {
        name: "Joylarda to'lov",
        
      },
      {
        name: "Click Terminal",
        
      },
      {
        name: "Telegram-bot",
       
      },
      {
        name: "Ekspress-to'lov",
        
      },
    
    ],
  },
 
];



export const clients = [
  {
    id: "client-1",
    logo: airbnb,
  },
  {
    id: "client-2",
    logo: binance,
  },
  {
    id: "client-3",
    logo: coinbase,
  },
  {
    id: "client-4",
    logo: dropbox,
  },
];