import React from "react";

const Button2 = ({ styles }) => (
    <a href="https://click.uz/uz/cards?utm_source=home&utm_medium=card&utm_campaign=order"><button type="button" className={`py-4 px-6 font-poppins font-medium text-[18px] text-primary bg-blue-gradient rounded-[10px] outline-none ${styles}`}>
    Buyurtma berish
  </button></a>
 
  
);


export default Button2;

