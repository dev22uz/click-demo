import React from "react";

const Button2 = ({ styles }) => (
  <a href="https://click-start.uz/"><button type="button" className={`py-4 px-6 font-poppins font-medium text-[18px] text-primary bg-blue-gradient rounded-[10px] outline-none ${styles}`}>
  Batafsil
</button></a>
  
);


export default Button2;

