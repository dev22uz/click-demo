import Navbar from "./Navbar";
import Billing from "./Billing";
import CardDeal from "./CardDeal";
import CardDeal2 from "./CardDeal2";
import CardDeal3 from "./CardDeal3";
import Business from "./Business";

import CTA from "./CTA";
import Stats from "./Stats";
import Footer from "./Footer";
import News from "./News";
import Hero from "./Hero";

export {
  Navbar,
  Billing,
  CardDeal,
  CardDeal2,
  CardDeal3,
  
  Business,
  
  CTA,
  Stats,
  Footer,
  News,
  Hero,
};
