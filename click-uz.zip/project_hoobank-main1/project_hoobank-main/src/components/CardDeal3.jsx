import { clickcard, clickup , evo1, evo2,evo3, humo, uzcard,} from "../assets";
import styles, { layout } from "../style";
import Button4 from "./Button4";

const CardDeal = () => (
  <section id="click-card" className={layout.section}>
    <div className={layout.sectionInfo}>
      
      <h2 className={styles.heading2}>
        <h1 className="flex-1 font-poppins font-semibold ss:text-[72px] text-[52px] text-white ss:leading-[100.8px] leading-[75px]">
          <span className="text-gradient">Click kartasiga ega bo'ling</span>{" "}
          </h1>
          2%gacha CASHBACK oling
      </h2>
     
    

      <Button4 styles={`mt-10`} />
      <div className="flex flex-row flex-wrap sm:mt-15 mt-6">
        <img src={uzcard} alt="google_play" className="w-[144.17px] h-[42.05px] object-contain mr-5 cursor-pointer" />
        
        <img src={humo} alt="google_play" className="w-[144.17px] h-[42.05px] object-contain cursor-pointer" />
        
        
      </div>
      
    </div>

    <div className={layout.sectionImg}>
      <img src={clickcard} alt="billing" className="w-[100%] h-[100%]" />
    </div>
    
  </section>
);

export default CardDeal;
