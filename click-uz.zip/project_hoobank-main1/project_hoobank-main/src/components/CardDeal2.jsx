import {  walletnew , } from "../assets";
import styles, { layout } from "../style";




const CardDeal2 = () => (
  <section id="click-hamyon" className={layout.section}>
    <div className={layout.sectionImg}>
      <img src={walletnew} alt="billing" className="w-[100%] h-[100%]" />
    </div>
    <div className={layout.sectionInfo}>
      
      <h2 className={styles.heading2}>
        <h1 className="flex-1 font-poppins font-semibold ss:text-[72px] text-[52px] text-white ss:leading-[100.8px] leading-[75px]">
          <span className="text-gradient">Click-hamyon</span>{" "}
          </h1>
          Yangi imkoniyatlarni ishlating
      </h2>
      <p className={`${styles.paragraph}   text-[32px] max-w-[600px] mt-5`}>
      
      </p>
    

      
    
      
    </div>

    
    
  </section>
);

export default CardDeal2;
