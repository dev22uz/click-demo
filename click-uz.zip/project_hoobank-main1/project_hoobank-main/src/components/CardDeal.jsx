import { clickup , evo1, evo2,evo3,} from "../assets";
import styles, { layout } from "../style";
import Button3 from "./Button3";

const CardDeal = () => (
  <section id="click-up" className={layout.section}>
    <div className={layout.sectionInfo}>
      
      <h2 className={styles.heading2}>
        <h1 className="flex-1 font-poppins font-semibold ss:text-[72px] text-[52px] text-white ss:leading-[100.8px] leading-[75px]">
          <span className="text-gradient">Click Up</span>{" "}
          </h1>
      Naqdsiz to'lovlarning <br className="sm:block hidden" />  yangi darajasi
      </h2>
      <p className={`${styles.paragraph}  max-w-[590px] mt-5`}>
      Ilovani o'zingizga moslab sozlang, aynan sizga kerakli funksiyalarni bosh ekranda o'rnating, ikki karra cashback oling va qabul qiluvchi karta yoki telefon raqamisiz pul o'tkazing. Hoziroq yuklab oling va qulaylikning yangi darajasini sinab ko'ring.
      </p>
    

      <Button3 styles={`mt-10`} />
      <div className="flex flex-row flex-wrap sm:mt-15 mt-6">
        <a href="https://play.google.com/store/apps/details?id=air.com.ssdsoftwaresolutions.clickuz"><img src={evo1} alt="google_play" className="w-[144.17px] h-[42.05px] object-contain mr-5 cursor-pointer" /></a>
        
        <a href="https://apps.apple.com/us/app/click-evolution/id768132591"><img src={evo2} alt="google_play" className="w-[144.17px] h-[42.05px] object-contain cursor-pointer" /></a>
        
        
      </div>
      
    </div>

    <div className={layout.sectionImg}>
      <img src={clickup} alt="billing" className="w-[100%] h-[100%]" />
    </div>
    
  </section>
);

export default CardDeal;
