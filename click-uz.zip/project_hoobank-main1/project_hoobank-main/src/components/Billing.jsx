import { evo1, mockup2, evo2, } from "../assets";
import styles, { layout } from "../style";
import Button2 from "./Button2";

const Billing = () => (
  <section id="start" className={layout.sectionReverse}>
    <div className={layout.sectionImgReverse}>
      <img src={mockup2} alt="billing" className="w-[100%] h-[100] relative z-[5]" />

      {/* gradient start */}
      <div className="absolute z-[3] -left-1/2 top-0 w-[50%] h-[50%] rounded-full white__gradient" />
      <div className="absolute z-[0] w-[50%] h-[50%] -left-1/2 bottom-0 rounded-full pink__gradient" />
      {/* gradient end */}
    </div>

    <div className={layout.sectionInfo}>
      <h2 className={styles.heading2}>
      <div className="flex flex-row justify-between items-center w-full">
          <h1 className="flex-1 font-poppins font-semibold ss:text-[72px] text-[52px] text-white ss:leading-[100.8px] leading-[75px]">
          <span className="text-gradient">Click Start</span>{" "}
          </h1>
          
          
        </div>
        
      

     
      </h2>
      <p className={`${styles.paragraph} ss:text-[32px] max-w-[600px]  mt-5`}>
      Bolalaringiz uchun yangi imkoniyatlardan foydalaning.
      </p>
      <Button2 styles={`mt-10`} />

      <div className="flex flex-row flex-wrap sm:mt-10 mt-6">
        <a href="https://play.google.com/store/apps/details?id=com.click.clickstart"><img src={evo1} alt="google_play" className="w-[144.17px] h-[42.05px] object-contain mr-5 cursor-pointer" /></a>
        <a href="https://apps.apple.com/us/app/click-start/id1590997023"><img src={evo2} alt="google_play" className="w-[144.17px] h-[42.05px] object-contain cursor-pointer" /></a>
        
      </div>
    </div>
  </section>
);

export default Billing;
