
import mockup from "./mockup-uz.png";
import mockup2 from "./mockup-uz-2.png";
import item from "./item.svg";
import item2 from "./item2.svg";
import item3 from "./item3.svg";
import item4 from "./item4.svg";
import evo1 from "./evo1.svg";
import evo2 from "./evo2.svg";
import evo3 from "./evo2.svg";
import clickup from "./clickup.png";
import walletnew from "./wallet_new.png";
import uzcard from "./uzcard.svg";
import humo from "./humo.svg";
import clickcard from "./card_click.png";
import blog from "./blog.jpg";
import blog2 from "./blog2.jpg";
import blog3 from "./blog3.png";









import airbnb from "./airbnb.png";
import bill from "./bill.png";
import binance from "./binance.png";
import card from "./card.png";
import coinbase from "./coinbase.png";
import dropbox from "./dropbox.png";
import logo from "./logos.png";
import quotes from "./quotes.svg";
import robot from "./robot.png";
import send from "./Send.svg";
import shield from "./Shield.svg";
import star from "./Star.svg";
import menu from "./menu.svg";
import close from "./close.svg";
import google from "./google.svg";
import apple from "./apple.svg";
import arrowUp from "./arrow-up.svg";
import discount from "./Discount.svg";
import facebook from "./facebook.svg";
import instagram from "./instagram.svg";
import linkedin from "./linkedin.svg";
import twitter from "./twitter.svg";
import people01 from "./people01.png";
import people02 from "./people02.png";
import people03 from "./people03.png";

export {
  mockup,
  mockup2,
  item,
  item2,
  item3,
  item4,
  evo1,
  evo2,
  evo3,
  clickup,
  walletnew,
  uzcard,
  humo,
  clickcard,
  blog,
  blog2,
  blog3,


  airbnb,
  bill,
  binance,
  card,
  coinbase,
  dropbox,
  logo,
  quotes,
  robot,
  send,
  shield,
  star,
  
  menu,
  close,
  google,
  apple,
  arrowUp,
  discount,
  facebook,
  instagram,
  linkedin,
  twitter,
  people01,
  people02,
  people03,
};
